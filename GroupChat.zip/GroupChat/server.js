const path = require('path');
const http = require('http');
const express = require('express');
const socketio = require('socket.io');
const formatMessage = require('./utils/messages');
const {
    newGroup,
    userJoin,
    getCurrentUser,
    userLeave,
    getRoomUsers
} = require('./utils/users');
// const Authen = require('./model/authenticate') schema for group name and password
const Room = require('./model/roomschema')
const mongoose = require('mongoose')
const connect = mongoose.connect('mongodb://localhost:27017/Group_Chat', { useNewUrlParser: true, useUnifiedTopology: true })

const app = express();
const server = http.createServer(app);
const io = socketio(server);

app.use(express.static(path.join(__dirname, 'public')));

const botName = 'GroupChat Bot';

io.on('connection', socket => {
    // socket.on('creategroup', ({ groupname, password }) => {
    //     const group = newGroup(socket.id, groupname, password);

    //     socket.join(group.groupname);

    //     connect.then(db => {
    //         let authenDetails = new Authen(group);                  inserting data to data base authentication details.
    //         authenDetails.save();
    //     })

    // })
    socket.on('joinRoom', ({ username, room, password }) => {
        const user = userJoin(socket.id, username, room, password);

        socket.join(user.room);

        connect.then(db => {
            let roomdetails = new Room(user);
            roomdetails.save();
        })

        socket.emit('message', formatMessage(botName, 'Welcome to GroupChat!'));

        socket.broadcast
            .to(user.room)
            .emit(
                'message',
                formatMessage(botName, `${user.username} has joined the chat`)
            );

        io.to(user.room).emit('roomUsers', {
            room: user.room,
            users: getRoomUsers(user.room)
        });
    });

    socket.on('chatMessage', msg => {
        const user = getCurrentUser(socket.id);

        io.to(user.room).emit('message', formatMessage(user.username, msg));
    });

    socket.on('disconnect', () => {
        const user = userLeave(socket.id);

        if (user) {
            io.to(user.room).emit(
                'message',
                formatMessage(botName, `${user.username} has left the chat`)
            );

            io.to(user.room).emit('roomUsers', {
                room: user.room,
                users: getRoomUsers(user.room)
            });
        }
    });
});

const PORT = process.env.PORT || 3000;

server.listen(PORT, () => console.log(`Server running on port ${PORT}`));
