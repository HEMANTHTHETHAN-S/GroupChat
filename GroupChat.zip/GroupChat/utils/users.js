const users = [];

const groups = [];

function newGroup(id, groupname, gpassword) {

    const group = { id, groupname, gpassword };
    console.log("newgroup" + group)
    groups.push(group);
    return group;
}

function userJoin(id, username, room, password) {
    const user = { id, username, room, password };
    // const users = new Room(user);
    users.push(user);
    console.log(users)
    return user;
}

function getCurrentUser(id) {
    // const users = Room.find({ id: _id })
    // return users;
    return users.find(user => user.id === id);
}

function userLeave(id) {
    // const users = Room.find({ id: _id })
    // Room.findOneAndDelete({ id: _id })
    // return users;
    const index = users.findIndex(user => user.id === id);

    if (index !== -1) {
        return users.splice(index, 1)[0];
    }
}

function getRoomUsers(room) {
    // const users = Room.find({ room: room })
    // return users;
    return users.filter(user => user.room === room)
}

module.exports = {
    newGroup,
    userJoin,
    getCurrentUser,
    userLeave,
    getRoomUsers
};