const mongoose = require('mongoose')
const connect = mongoose.connect('mongodb://localhost:27017/Group_Chat', { useNewUrlParser: true, useUnifiedTopology: true })
const moment = require('moment');
const Chat = require('../model/chatschema')

function formatMessage(username, text) {
    connect.then(db => {
        console.log("Mongo is connected...");
        let chatMessage = new Chat({
            username,
            text,
            time: moment().format('h:mm a')
        });
        chatMessage.save();
    })
    return {
        username,
        text,
        time: moment().format('h:mm a')
    }

}


module.exports = formatMessage;