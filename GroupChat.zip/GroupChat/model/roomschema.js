const mongoose = require('mongoose')
const roomSchema = new mongoose.Schema({
    id: {
        type: String
    },
    username: {
        type: String
    },
    room: {
        type: String
    },
    password: {
        type: String
    }
})

const Room = mongoose.model('Room', roomSchema)
module.exports = Room;