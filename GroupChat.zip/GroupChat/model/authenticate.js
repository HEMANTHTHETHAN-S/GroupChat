const mongoose = require('mongoose')
const authenSchema = new mongoose.Schema({
    id: {
        type: String
    },
    groupname: {
        type: String
    },
    password: {
        type: String
    }
})

const Authen = mongoose.model('Authen', authenSchema)
module.exports = Authen